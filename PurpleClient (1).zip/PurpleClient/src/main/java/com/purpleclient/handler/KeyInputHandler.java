package com.purpleclient.handler;

import com.purpleclient.hud.HUDOverlay;

import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;

import org.lwjgl.input.Keyboard;

public class KeyInputHandler {

    // Default toggle key: Right Shift. Change it in-game from Controls menu (category: Purple-Client).
    public static final KeyBinding toggleHudKey =
            new KeyBinding("key.purpleclient.toggle", Keyboard.KEY_RSHIFT, "key.categories.purpleclient");

    @SubscribeEvent
    public void onKeyInput(InputEvent.KeyInputEvent event) {
        if (toggleHudKey.isPressed()) {
            HUDOverlay.hudEnabled = !HUDOverlay.hudEnabled;
        }
    }
}
