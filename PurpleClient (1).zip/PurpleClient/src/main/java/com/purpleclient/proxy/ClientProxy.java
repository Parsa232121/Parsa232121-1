package com.purpleclient.proxy;

import com.purpleclient.handler.KeyInputHandler;
import com.purpleclient.hud.ClickTracker;
import com.purpleclient.hud.HUDOverlay;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

public class ClientProxy extends CommonProxy {

    @Override
    public void preInit(FMLPreInitializationEvent event) {
        super.preInit(event);
        ClientRegistry.registerKeyBinding(KeyInputHandler.toggleHudKey);
    }

    @Override
    public void init(FMLInitializationEvent event) {
        super.init(event);
        MinecraftForge.EVENT_BUS.register(new KeyInputHandler());
        MinecraftForge.EVENT_BUS.register(new ClickTracker());
        MinecraftForge.EVENT_BUS.register(new HUDOverlay());
    }
}
