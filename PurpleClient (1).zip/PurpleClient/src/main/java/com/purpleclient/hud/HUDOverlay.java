package com.purpleclient.hud;

import java.util.List;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.item.EntityTNTPrimed;
import net.minecraft.util.AxisAlignedBB;

import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import org.lwjgl.input.Keyboard;

/**
 * Draws the Purple-Client HUD:
 *  - FPS counter (top-left)
 *  - CPS counter, left/right click (top-left, below FPS)
 *  - TNT fuse countdown for nearby primed TNT (top-center)
 *  - WASD key press indicator (bottom-right)
 *
 * No gameplay-affecting logic here - purely visual/informational.
 */
public class HUDOverlay extends Gui {

    public static boolean hudEnabled = true;

    private static final int ACCENT_COLOR = 0xFF9B30FF; // purple accent
    private final Minecraft mc = Minecraft.getMinecraft();

    @SubscribeEvent
    public void onRenderOverlay(RenderGameOverlayEvent.Post event) {
        if (!hudEnabled) return;
        if (event.type != RenderGameOverlayEvent.ElementType.ALL) return;
        if (mc.gameSettings.showDebugInfo) return; // don't clash with F3 debug screen
        if (mc.thePlayer == null) return;

        ScaledResolution sr = new ScaledResolution(mc);

        drawFps();
        drawCps();
        drawTntCountdown(sr);
        drawKeys(sr);
    }

    private void drawFps() {
        int fps = Minecraft.getDebugFPS();
        drawStringWithShadow("FPS: " + fps, 4, 4, ACCENT_COLOR);
    }

    private void drawCps() {
        int left = ClickTracker.getLeftCPS();
        int right = ClickTracker.getRightCPS();
        drawStringWithShadow("CPS: " + left + " | " + right, 4, 14, ACCENT_COLOR);
    }

    private void drawTntCountdown(ScaledResolution sr) {
        if (mc.theWorld == null) return;

        AxisAlignedBB searchBox = mc.thePlayer.getEntityBoundingBox().expand(16.0D, 16.0D, 16.0D);
        List<EntityTNTPrimed> tntList = mc.theWorld.getEntitiesWithinAABB(EntityTNTPrimed.class, searchBox);
        if (tntList.isEmpty()) return;

        EntityTNTPrimed closest = null;
        double closestDistSq = Double.MAX_VALUE;
        for (EntityTNTPrimed tnt : tntList) {
            double distSq = tnt.getDistanceSqToEntity(mc.thePlayer);
            if (distSq < closestDistSq) {
                closestDistSq = distSq;
                closest = tnt;
            }
        }
        if (closest == null) return;

        float seconds = closest.getFuse() / 20.0f;
        String text = String.format("TNT %.2fs", seconds);
        int color = seconds <= 1.0f ? 0xFFFF5555 : 0xFFFFFFFF;

        int textWidth = mc.fontRendererObj.getStringWidth(text);
        int x = (sr.getScaledWidth() - textWidth) / 2;
        drawStringWithShadow(text, x, 30, color);
    }

    private void drawKeys(ScaledResolution sr) {
        int size = 18;
        int gap = 2;
        int baseX = sr.getScaledWidth() - (size * 3 + gap * 2) - 10;
        int baseY = sr.getScaledHeight() - (size * 2 + gap) - 10;

        boolean w = isDown(mc.gameSettings.keyBindForward);
        boolean a = isDown(mc.gameSettings.keyBindLeft);
        boolean s = isDown(mc.gameSettings.keyBindBack);
        boolean d = isDown(mc.gameSettings.keyBindRight);

        drawKey("W", baseX + size + gap, baseY, size, w);
        drawKey("A", baseX, baseY + size + gap, size, a);
        drawKey("S", baseX + size + gap, baseY + size + gap, size, s);
        drawKey("D", baseX + (size + gap) * 2, baseY + size + gap, size, d);
    }

    private boolean isDown(KeyBinding kb) {
        int code = kb.getKeyCode();
        if (code == 0) return false;
        return Keyboard.isKeyDown(code);
    }

    private void drawKey(String label, int x, int y, int size, boolean active) {
        int bg = active ? 0xCC9B30FF : 0x66000000;
        int border = 0xFF9B30FF;

        drawRect(x, y, x + size, y + size, bg);
        // simple border (top, bottom, left, right 1px lines)
        drawRect(x, y, x + size, y + 1, border);
        drawRect(x, y + size - 1, x + size, y + size, border);
        drawRect(x, y, x + 1, y + size, border);
        drawRect(x + size - 1, y, x + size, y + size, border);

        int tw = mc.fontRendererObj.getStringWidth(label);
        mc.fontRendererObj.drawStringWithShadow(label, x + (size - tw) / 2f, y + (size - 8) / 2f, 0xFFFFFFFF);
    }

    private void drawStringWithShadow(String text, int x, int y, int color) {
        mc.fontRendererObj.drawStringWithShadow(text, x, y, color);
    }
}
