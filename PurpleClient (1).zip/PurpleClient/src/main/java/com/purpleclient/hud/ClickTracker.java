package com.purpleclient.hud;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

import org.lwjgl.input.Mouse;

import java.util.LinkedList;

/**
 * Tracks left/right mouse click timestamps to compute clicks-per-second (CPS).
 * Purely observational - does not send extra clicks, does not auto-click.
 */
public class ClickTracker {

    private static final LinkedList<Long> leftClicks = new LinkedList<Long>();
    private static final LinkedList<Long> rightClicks = new LinkedList<Long>();

    private static boolean lastLeft = false;
    private static boolean lastRight = false;

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        boolean left = Mouse.isButtonDown(0);
        boolean right = Mouse.isButtonDown(1);
        long now = System.currentTimeMillis();

        if (left && !lastLeft) leftClicks.add(now);
        if (right && !lastRight) rightClicks.add(now);

        lastLeft = left;
        lastRight = right;

        purge(leftClicks, now);
        purge(rightClicks, now);
    }

    private void purge(LinkedList<Long> list, long now) {
        while (!list.isEmpty() && now - list.getFirst() > 1000) {
            list.removeFirst();
        }
    }

    public static int getLeftCPS() {
        return countRecent(leftClicks);
    }

    public static int getRightCPS() {
        return countRecent(rightClicks);
    }

    private static int countRecent(LinkedList<Long> list) {
        long now = System.currentTimeMillis();
        int count = 0;
        for (Long t : list) {
            if (now - t <= 1000) count++;
        }
        return count;
    }
}
