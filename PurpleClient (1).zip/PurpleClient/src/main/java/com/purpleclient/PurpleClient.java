package com.purpleclient;

import com.purpleclient.proxy.CommonProxy;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.Mod.Instance;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

/**
 * Purple-Client
 * A clean (no-cheat) PvP utility HUD mod for Minecraft 1.8.9 Forge.
 * Inspired by Lunar Client's HUD: FPS, CPS, TNT fuse countdown, WASD key overlay.
 */
@Mod(modid = PurpleClient.MODID, name = PurpleClient.NAME, version = PurpleClient.VERSION, clientSideOnly = true)
public class PurpleClient {

    public static final String MODID = "purpleclient";
    public static final String NAME = "Purple-Client";
    public static final String VERSION = "1.0.0";

    @Instance(MODID)
    public static PurpleClient instance;

    @SidedProxy(clientSide = "com.purpleclient.proxy.ClientProxy", serverSide = "com.purpleclient.proxy.CommonProxy")
    public static CommonProxy proxy;

    @EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        proxy.preInit(event);
    }

    @EventHandler
    public void init(FMLInitializationEvent event) {
        proxy.init(event);
    }
}
